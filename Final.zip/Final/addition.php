<?php

	if (isset($_POST['submitted']) && $_POST['submitted'] == 'true') {

		if (isset($_POST['ID']) && empty($_POST['ID'])) {

			// display error message (userID is empty)
			echo "<script type='text/javascript'>
			alert('Error: Please enter your ID.');
			history.go(-1);
			</script>";

		} else if (isset($_POST['Name']) && empty($_POST['Name'])) {

			// display error message (password is empty)
			echo "<script type='text/javascript'>
			alert('Error: Please enter your place name.');
			history.go(-1);
			</script>";

		} 
		else if (isset($_POST['Description']) && empty($_POST['Description'])) {

			// display error message (email is empty)
			echo "<script type='text/javascript'>
			alert('Error: Please enter the description.');
			history.go(-1);
			</script>";

		} 
		
		else if (isset($_POST['Image']) && empty($_POST['Image'])) {

			// display error message (email is empty)
			echo "<script type='text/javascript'>
			alert('Error: Please enter the name of the image.');
			history.go(-1);
			</script>";

		} 	
		else if (isset($_POST['Map']) && empty($_POST['Map'])) {

			// display error message (email is empty)
			echo "<script type='text/javascript'>
			alert('Error: Please enter the map.');
			history.go(-1);
			</script>";

		} 
		
		else {
			
			
			$dbhost = 'localhost';
			$dbuser = 'root';
			$dbpass = '';
			$dbname = 'places';
			$conn = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);

				if ($conn->connect_error) {
               die("Connection failed: " . $conn->connect_error);
            } 
            $sql = "INSERT INTO destination (ID,Name,Description,Image,Map)VALUES ('".$_POST["ID"]."','".$_POST["Name"]."','".$_POST["Description"]."','".$_POST["Image"]."','".$_POST["Map"]."')";

            if (mysqli_query($conn, $sql)) {
            echo "<script type='text/javascript'>
			alert('Data has been successfully created');
			window.top.location='viewPlaces.php';
			</script>";
            } 
			else {
            echo "<script type='text/javascript'>
			alert('Data has not been successfully created');
			window.top.location='addition.php';
			</script>" . $sql . "" . mysqli_error($conn);
            }
            $conn->close();
         }
		}
		
	 else {

include 'headerAdmin.php';
?>
   <!-- Start Register section -->
  <section id="contact">
    <div class="container">
      <div class="row">
        <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="contact-left wow fadeInLeft">
            <h2>Add new Data</h2>
            <form action="addition.php" class="contact-form" method="post">
              <div class="form-group">                
                <input type="number" name="ID" class="form-control" placeholder="ID">
              </div>
              <div class="form-group">                
                <input type="text" name="Name" class="form-control" placeholder="Name">
              </div>  
			  <div class="form-group">                
			  <textarea name="Description" class = "form-control" rows="5" cols="40" placeholder="Description"></textarea>
              </div> 
              <div class="form-group">                
              <input type="text" name="Image" class="form-control" placeholder="Image">
              </div> 
			  <div class="form-group">                
              <input type="text" name="Map" class="form-control" placeholder="Map">
              </div> 
            

			 
			  <input type='hidden' name="submitted" value='true'>
              <button type="submit" data-text="SUBMIT" class="button button-default"><span>SUBMIT</span></button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End Register section -->

<?php
include('footer.html');
  }
?>