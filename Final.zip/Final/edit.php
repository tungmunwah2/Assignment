 <?php
 include('headerAdmin.php');
 
		//Connect to MySQL
		$con = mysqli_connect('127.0.0.1','root','','places');
		
		//Select database
		mysqli_select_db($con,'places');
		
		//Select query
		$sql = "SELECT * FROM destination WHERE ID = ".$_POST['id'];
		
		//Execute the query
		$records = mysqli_query($con, $sql);				
		$place = mysqli_fetch_array($records);

		?>
 
<head>
</head>
<body>
  	<section id="contact">
    <div class="container">
      <div class="row">
        <div class="col-md-5 col-sm-10 col-xs-12">
          <div class="contact-left wow fadeInLeft">
            <h2>Edit Data</h2>
			<form action="update.php" class="contact-form" method="post" enctype="multipart/form-data">
	        <div class="form-group">    

	<div class="form-group">                
    <input type="number" name = "id" class="form-control" placeholder="ID" value = "<?php echo $place['ID']; ?>">
    </div>			
	 
	<div class="form-group">                
    <input type="text" name = "name" class="form-control" placeholder="Name" value = "<?php echo $place['Name']; ?>">
    </div>
	
	<div class="form-group">                
	<textarea name="description" class = "form-control" rows="5" cols="40" placeholder="Description"><?php echo $place['Description']; ?></textarea>
    </div>
	
	<div class="form-group">                
    <input type="text" name = "image" class="form-control" placeholder="Image" value = "<?php echo $place['Image']; ?>">
    </div>

	<div class="form-group">   
    <input type="text" name = "map" class="form-control" placeholder="Map" value = "<?php echo $place['Map']; ?>">
    </div>
	

	
	
	
	<button type="submit" data-text="SUBMIT" class="button button-default"><span>Update</span></button>
	
	</form>
	</section>              
	<br>
	</form>
</body>
<?php
include('footer.html');
?>