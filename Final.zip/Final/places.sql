-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 25, 2020 at 03:57 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `places`
--

-- --------------------------------------------------------

--
-- Table structure for table `destination`
--

CREATE TABLE `destination` (
  `ID` int(10) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Description` longtext NOT NULL,
  `Image` varchar(200) NOT NULL,
  `Map` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `destination`
--

INSERT INTO `destination` (`ID`, `Name`, `Description`, `Image`, `Map`) VALUES
(1, 'Port Dickson', 'Port Dickson is a town on Malaysia’s west coast, south of Kuala Lumpur. Beaches dot the coastline running south toward Tanjung Tuan, a wildlife reserve and birdwatching spot with a 16th-century lighthouse. East of the reserve is Fort Kempas, with a 14th- or 15th-century sacred Islamic tomb and several megaliths. Lukut Museum, northeast of Port Dickson, has exhibits about the area’s history from the early 1800s.', 'images/Portdickson.jpg\r\n', 'https://www.google.com/maps?q=Port+Dickson&rlz=1C1GCEA_enMY893MY893&um=1&ie=UTF-8&sa=X&ved=2ahUKEwj9-Z6Z7NvqAhXQ8XMBHU_0BIMQ_AUoAXoECBsQAw'),
(2, 'Hi', 'testing', 'images/Langkawi.jpg', 'https://elearning.newinti.edu.my/');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `destination`
--
ALTER TABLE `destination`
  ADD PRIMARY KEY (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
