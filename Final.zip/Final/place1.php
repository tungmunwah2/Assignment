<?php


	include('header1.php');

?>
<?php
   $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
   $dbname = 'places';
   $conn = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);
   
   if(! $conn ) {
      die('Could not connect: ' . mysqli_error());
   }
   $sql = 'SELECT Name, Description, Image , Map  FROM destination ORDER BY ID';
   $result = mysqli_query($conn, $sql);

   if (mysqli_num_rows($result) > 0) {
      while($row = mysqli_fetch_assoc($result)) {
		  	$name = $row['Name'];
			$description = $row['Description'];
			$image = $row ['Image'];
			$map = $row ['Map'];

		  	echo "
			 <section id='team'>
				<div class='container'>
					<div class='row'>
						<div class='col-md-12'>
							<div class='team-area'>
								<div class='title-area'>
									<h2 class='tittle'>$name</h2>
										<span class='tittle-line'></span>
											<p></p>
								</div>
							</div>
						</div>
					</div>
				</div>
							
							
		<div class='row'>
			<div class='col-md-12'>
				<div class='about-area'>
					<div class='row'>
						<div class='col-md-5 col-sm-6 col-xs-12'>
							<div class='about-left wow fadeInLeft'>
							<img src='$image' height='410' width='500' alt='img'>
							</div>
						</div>
							<div class='col-md-7 col-sm-6 col-xs-12'>
								<div class='about-right wow fadeInRight>
									<div class='title-area'>
                   
									<p>$description</p>
	
										<div class='about-btn-area'>
											<a href='$map'
											class='button button-default' data-text='GET LOCATION'><span>GET LOCATION</span></a>
										</div>                    
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
							
													
				";

      }
   } else {
      echo "0 results";
   }
   mysqli_close($conn);
?>

<?php
include('footer.html');
?>