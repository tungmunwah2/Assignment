<?php
 include('headerAdmin.php');
 ?>
<table border=1 cellpadding=1 cellspacing=1>
	<tr>
		<th style="text-align:center;min-width:200px;">UserID</th>
		<th style="text-align:center;min-width:100px;">Password</th>
		<th style="text-align:center;min-width:100px;">Email</th>
		<th style="text-align:center;min-width:150px;">Birthday</th>
		<th style="text-align:center;min-width:200px;">Address</th>



	</tr>
	<?php
		//Connect mySQL
			$connection = mysqli_connect('localhost','root','','malaysia');
		
		//Select Database
			mysqli_select_db($connection, 'malaysia');
			
		
		//Select Query
			$sql = "SELECT * FROM user";
		
		//Execute Query
			$records = mysqli_query($connection,$sql);
		
		while($user = mysqli_fetch_array($records)){
			echo "<tr>";
			echo "<td style='text-align:center;'>".$user['userID']."</td>";
			echo "<td style='text-align:center;'>".$user['Password']."</td>";
			echo "<td style='text-align:center;'>".$user['Email']."</td>";
			echo "<td style='text-align:center;'>".$user['Birthday']."</td>";
			echo "<td style='text-align:center;'>".$user['Address']."</td>";
			echo" <td><table border=0'><td style='border-left: none;'>

			</td></table></td>";
			echo "</tr>";
			
			
		}
	?>
</table>
<br>
</body>
<?php
include('footer.html');
?>

