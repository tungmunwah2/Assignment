<?php
 include('headerAdmin.php');
 ?>
 <head>
</head>
<body>
<table border=1 cellpadding=1 cellspacing=1>
	<tr>
		<th style="text-align:center;min-width:100px;">Name</th>
		<th style="text-align:center;min-width:200px;">Description</th>
		<th style="text-align:center;min-width:300px;">Image</th>
				<th style="text-align:center;min-width:50px;">Map</th>

		<th style="text-align:center;min-width:300px;">Action</th>



	</tr>
	<?php
		//Connect mySQL
			$connection = mysqli_connect('localhost','root','','places');
		
		//Select Database
			mysqli_select_db($connection, 'places');
			
		
		//Select Query
			$sql = "SELECT * FROM destination ORDER BY ID";
		
		//Execute Query
			$records = mysqli_query($connection,$sql);
		
		while($user = mysqli_fetch_array($records)){
			echo "<tr>";
			echo "<td style='text-align:center;'>".$user['Name']."</td>";
			echo "<td style='text-align:center;'>".$user['Description']."</td>";
			echo "<td style='text-align:center;'><img src = '".$user['Image'] . "' height='250' width='250'></td>" ;
			echo "<td style='text-align:center;'>".$user['Map']."</td>";

			echo" <td><table border=0'><text-align:center;'>
				<form action = 'del.php' method = 'POST'> 
					<input type = 'hidden' name='id' value  = '".$user['ID']."'>
					<input type='submit' value='Delete'>
				</form>
				<br>
				<br>
				<form action = 'edit.php' method = 'POST'> 
					<input type = 'hidden' name='id' value  = '".$user['ID']."'>
					<input type='submit' value='Edit'>
				</form>
				</td></table></td>";
				echo "</tr>";
			
			
		}
	?>
</table>
<br>
</body>
<?php
include('footer.html');
?>

