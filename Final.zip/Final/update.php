<?php 
	//Connect to MySQL
		$con = mysqli_connect('127.0.0.1','root','','places');
		
		//Select database
		mysqli_select_db($con,'places');
		
		//Update query
		
		$sql = "UPDATE destination SET Name='".$_POST['name']."', Description ='".$_POST['description']."',
		Image ='".$_POST['image']."', Map='".$_POST['map']."'
		WHERE ID = ".$_POST['id'].";";
		
		//Execute the query
		if(mysqli_query($con, $sql))
			header("refresh:1,url=viewPlaces.php");
		else
			echo "Not Updated";
?>