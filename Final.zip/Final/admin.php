<?php
 include('headerAdmin.php');
 ?>
<!-- Start service section -->
  <section id="service">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="service-area">
            <div class="title-area">
              <h2 class="tittle">Admin Page</h2>
              <span class="tittle-line"></span>
              <p></p>
            </div>
            <!-- service content -->
            <div class="service-content">
 

              <ul class="service-table ">
                <li class="col-md-3 col-sm-6">
                  <div class="single-service wow slideInUp">
                    <a href="addition.php"><img src="images/adba79333a171aa4475d19ec53e6cbd6.png" width="200" height="200" alt=""> </a> 
                    <h4 class="service-title">Add Place</h4>
                    <p></p>
                  </div>
                </li>
                <li class="col-md-3 col-sm-6">
                  <div class="single-service wow slideInUp">
                     <a href="viewPlaces.php"><img src="images/edit.jpg" width="200" height="200" alt=""> </a> 
                    <h4 class="service-title">Edit/Delete</h4>
                    <p></p>
                  </div>
                </li>
                 <li class="col-md-3 col-sm-6">
                  <div class="single-service wow slideInUp">
                     <a href="Account.php"><img src="images/account-icon-20.jpg" width="200" height="200" alt=""> </a> 
                    <h4 class="service-title">Customer</h4>
                    <p></p>
                  </div>
                </li>
				
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End service section -->
  <?php
include('footer.html');
?>
