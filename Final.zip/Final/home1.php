
<?php
	include('header1.php');
 ?>
  <!-- Start header section -->  
  <header id="header">
    <div class="header-inner">
      <!-- Header image -->
      <img src="assets/images/header-bg.jpg" alt="img">
      <div class="header-overlay">
        <div class="header-content">
        <!-- Start header content slider -->
        <h2 class="header-slide">We Have The
          <span> Latest </span>
          <span>Popular</span>
          <span> Most Visited </span>
          Places In Malaysia</h2>
        <!-- End header content slider -->  
        <!-- Header btn area -->
        <div class="header-btn-area">
          <a class="knowmore-btn" href="about.php">KNOW MORE</a>
        </div>
      </div>
      </div>      
    </div>
</body>
  <!-- End header section -->
  
   <?php
include('footer.html');
?>