<?php
	include('header1.php');
 ?>
<!-- Start about section -->
  <section id="about">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <!-- Start welcome area -->
          <div class="welcome-area">
            <div class="title-area">
              <h2 class="tittle">Welcome to <span>Malaysia.com</span></h2>
             
              <p></p>
            </div>
			 </ul>
            </div>
          </div>
          <!-- End welcome area -->
        </div>
      </div>
  <!-- Start Team action -->
  <section id="team">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="team-area">
            <div class="title-area">
              <h2 class="tittle">Meet the creator</h2>
              <span class="tittle-line"></span>
              <p></p>
            </div>
            <!-- Start team content -->
            <div class="team-content">
              <ul class="team-grid">
                <li>
                  <div class="team-item team-img-2 wow fadeInUp">
                    <div class="team-info">
                      <p>Hello!! I'm Tung Mun Wah</p>
                      <a href="https://www.facebook.com/tung.munwah"><span class="fa fa-facebook"></span></a>
                     
                    </div>
                  </div>
                  <div class="team-address">
                    <p>Tung Mun Wah</p>
					</div>
                </li>
              </ul>
            </div>
            <!-- End team content -->
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- Start Team action -->
<div class="row">
        <div class="col-md-12">
          <div class="about-area">
            <div class="row">
              <div class="col-md-5 col-sm-6 col-xs-12">
                <div class="about-left wow fadeInLeft">
                  <img src="assets/images/about-img.jpg" alt="img">
                  <a class="introduction-btn" >Introduction</a>
                </div>
              </div>
              <div class="col-md-7 col-sm-6 col-xs-12">
                <div class="about-right wow fadeInRight">
                  <div class="title-area">
                    <h2 class="tittle">About <span>Malaysia.com</span></h2>
                   
                    <p>Welcome to Malaysia.com, and thank you for visiting us! </p> 

                    <p>Actually I dont even know what to write anything so i leave it to u. xD</p>
	
	<p>Thanks again for visiting us!</p>
                    <div class="about-btn-area">
                      <a href="categories.php" class="button button-default" data-text="LEARN MORE"><span>LEARN MORE</span></a>
                    </div>                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
  </section> 

   <?php
include('footer.html');
?>